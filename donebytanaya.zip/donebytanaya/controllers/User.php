<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

 Public function __construct() { 
         parent::__construct(); 
		 $this->load->model('usermodel');
      } 
	  
	public function index()
	{
		//$search_string = "";
     ///
       // $search_string =  $this->input->post('usersearch', TRUE);
      //  $result = $this->usermodel->getDataList($search_string);
		//$data['search_string'] = $search_string;

       // $data['result'] = $result;
		
		$search_string = "";
        $search_string =  $this->input->post('usersearch', TRUE);
		$data=array();
		$employeeList=$this->usermodel->getList($search_string);
		$data['UserData']=$employeeList;
		$data['search_string'] = $search_string;
		$this->load->view('userlist',$data);
	}
	public function addcust(){
		$this->load->view('adduser');
	}
	
	public function save_user(){
		
		
		//echo"Tanaya";
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$contactno=$this->input->post('contactno');
		$city=$this->input->post('city');
		$status=$this->input->post('status');
		
		$displayUser=array(
			'name'=>$name,
			'email'=>$email,
			'contactno'=>$contactno,
			'city'=>$city,
			'status'=>$status
		);
		$this->usermodel->addUSER($displayUser);
		$this->session->set_flashdata('message', 'User added Successfully..');
		redirect('user/index');
	}
	
	public function editUser($id){
		//echo "Tanaya id==>".$id;
		
		$returnData=$this->usermodel->editUser($id);
		$editdetails['id']=$id;
		$editdetails['EDITUSER']=$returnData;
		$this->load->view('edituser',$editdetails);
	}
	
	public function update_user($id){
		
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$contactno=$this->input->post('contactno');
		$city=$this->input->post('city');
		$status=$this->input->post('status');
		
		$updateUser=array(
			'name'=>$name,
			'email'=>$email,
			'contactno'=>$contactno,
			'city'=>$city,
			'status'=>$status
		);
		$this->usermodel->updateUser($id,$updateUser);
		$this->session->set_flashdata('message', 'User updated Successfully..');
		redirect('user/index');
	}
	
	public function deleteUser($id){
		$this->usermodel->deleteuser($id);
		$this->session->set_flashdata('message', 'User deleted Successfully..');
		redirect('user/index');
		//echo"Lokare===?".$id;
	}
	
	public function updateStatus($status, $id) {
		
			$updateUser=array(
			'status'=>$status
		);
		$this->usermodel->updateUser($id,$updateUser);
		$this->session->set_flashdata('message', 'User status updated Successfully..');
		redirect('user/index');
		
	}
}
