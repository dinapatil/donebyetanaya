<?php
class Usermodel extends CI_Model {
	   function getList($search_string){
		   $this->db->select('*');
            $this->db->from('customer');
            if (!empty($search_string)) {
                $this->db->where(" ( name like '%$search_string%' OR email like '%$search_string%' OR contactno like '%$search_string%'  OR city like '%$search_string%' )");
            }
            
			$this->db->order_by('id','DESC');
            $query = $this->db->get();
       //   echo $this->db->last_query(); //exit;
            if (($query)) {
                return $query->result();
            } else {
                throw new Exception("Failed to connct database");
            }
	   }
		  function addUSER($displayUser){
			  $this->db->insert('customer',$displayUser);
			  return true;  
		  }
		  
		  function editUser($id){
			  $result=$this->db->query("select * from customer where id='".$id."'");
			  return $result->row_array();  
		  }
		  function updateUser($id,$updateUser){
			   $this->db->where('id',$id);
			   $this->db->update('customer',$updateUser);
			  // echo $this->db->last_query();exit;
			    return true;     
		  }
		  
		  function deleteuser($id){
			   $result=$this->db->query("delete from customer where id='".$id."'");
			   return true;
		  }
	  
}

?>

