<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <style>
.error {
  color:red;
} 
</style>
</head>
<body>

<div class="container">
  <h2>Add User Form</h2>
  <form id="adduser" name="adduser" class="form-horizontal" action="<?php echo base_url('index.php/user/save_user')?>" method="post">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name">
      </div>
    </div>
	
	 <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email-id:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Enter Email-ID" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Conatct No:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="contactno" placeholder="Enter Conatct No" name="contactno">
      </div>
    </div>
	
	 <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">City</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="city" placeholder="Enter City" name="city">
      </div>
    </div>
	
	 <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Status</label>
      <div class="col-sm-10">          
       <input type="radio" name="status" value="active"> Active
		<input type="radio" name="status" value="inactive"> Inactive
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-success">Submit</button>
       <a href="<?php echo base_url('index.php/user/index')?> "> <button type="button" class="btn btn-default">Cancel</button></a>
      </div>
    </div>
  </form>
</div>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
</body>
</html>
<script>
$('#adduser').validate({
  rules: {
    name: 'required',
    email: 'required',
    contactno: 'required',
    city: 'required',
    status: 'required'
  },
  
  submitHandler: function(form) {
    form.submit();
  }
});
</script>
