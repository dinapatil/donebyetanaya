<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>User List</h2>
   <?php if($this->session->flashdata('message')){?>
   <div class="alert alert-success">
		<?php echo $this->session->flashdata('message');?>
	</div>
   <?php }?>
  <div class="table-responsive">   
<a href="<?php echo base_url('index.php/user/addcust'); ?>"><button type="button" class="btn btn-primary">Add Customer</button>  </a>
<form method="post" action="<?php echo base_url('index.php/user/index'); ?>" id="frmSearch" name="frmSearch">
<input type="text"  placeholder="Search..." id="usersearch" name="usersearch" value="<?php echo !empty($search_string) ? $search_string : ''; ?>">
<a onclick="js_search_list();" href="JavaScript:void(0);" class="btn btn-success waves-effect w-md waves-light  m-b-5">SEARCH</a>
</form>
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Firstname</th>
        <th>EmailId</th>
        <th>Contact </th>
        <th>City</th>
        <th>Status</th>
        <th>Action</th>

      </tr>
    </thead>
    <tbody>
	<?php 
	$srno=1;
			foreach($UserData as $userarray){
				
				$id=$userarray->id;
				$name=$userarray->name;
				$email=$userarray->email;
				$contactno=$userarray->contactno;
				$city=$userarray->city;
				$status=$userarray->status;
	
	?>
      <tr>
        <td><?php echo $srno; ?></td>
        <td><?php echo $name; ?></td>
        <td><?php echo $email; ?></td>
        <td><?php echo $contactno; ?></td>
        <td><?php echo $city; ?></td>
        <td>
		
		<?php

		if($status == 'Active') {
			
			echo '<a href="'.base_url('index.php/user/updateStatus/Inactive/'.$id).'">Active</a>';
		
		} else {
			echo '<a href="'.base_url('index.php/user/updateStatus/Active/'.$id).'">Inactive</a>';
		}
		?>
		
		</td>
       <td><a href="<?php echo base_url('index.php/user/editUser/'.$id); ?>"><button type="button" class="btn btn-primary">Edit</button>  </a> |  
	   <a href="<?php echo base_url('index.php/user/deleteUser/'.$id); ?>"><button type="button" class="btn btn-primary">Delete</button>  </a></td>
      </tr>
	  <?php 
	  	$srno++;
		 }
										
	  ?>
    </tbody>
  </table>
  </div>
</div>

</body>
</html>

<script>
	
    function js_search_list() {
        document.getElementById("frmSearch").submit();
    }
   
</script>